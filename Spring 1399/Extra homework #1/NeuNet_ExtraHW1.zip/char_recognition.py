# Neural Networks
# Bonus Assignment

##############################      Main      #################################

def read_train_file(file="OCR_train.txt"):
    training_data_list = []
    train_file = open(file, "r")
    for line in train_file:
        line = list(line.replace(" ", ""))
        line = [int(x) * 2 - 1 for x in line if x != "\n"]
        training_data_list.extend([line[:]])
    return training_data_list


###############                 Training                     ##################
 

###############          Enter your code below ...           ##################
    










###############          Enter your code above ...           ##################
    


print("\nThe Neural Network has been trained in " + str(epoch) + " epochs.")



###############                   Testing                    ##################



###############          Enter your code below ...           ##################
    










###############          Enter your code above ...           ##################

print("\n\nPercent of Error in NN: " + str(_error / _total))













